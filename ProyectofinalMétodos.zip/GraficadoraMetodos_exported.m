classdef GraficadoraMetodos_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                     matlab.ui.Figure
        GraficadoradeFuncionesLabel  matlab.ui.control.Label
        Label_2                      matlab.ui.control.Label
        Label                        matlab.ui.control.Label
        fxEditField                  matlab.ui.control.EditField
        fxEditFieldLabel             matlab.ui.control.Label
        RazEditField                 matlab.ui.control.EditField
        RazEditFieldLabel            matlab.ui.control.Label
        YMnimoEditField              matlab.ui.control.NumericEditField
        YMnimoEditFieldLabel         matlab.ui.control.Label
        YMximoEditField              matlab.ui.control.NumericEditField
        YMximoEditFieldLabel         matlab.ui.control.Label
        XMnimoEditField              matlab.ui.control.NumericEditField
        XMnimoEditFieldLabel         matlab.ui.control.Label
        XMximoEditField              matlab.ui.control.NumericEditField
        XMximoEditFieldLabel         matlab.ui.control.Label
        GraficarButton               matlab.ui.control.Button
        IndicacionesLabel            matlab.ui.control.Label
        UIAxes                       matlab.ui.control.UIAxes
    end

    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: GraficarButton
        function GraficarButtonPushed(app, event)

        % Obtener la función ingresada por el usuario
        funcionIngresada = app.fxEditField.Value;

        % Evaluamos los límites ingresados 
        xmin = app.XMnimoEditField.Value;
        xmax = app.XMximoEditField.Value;
        ymin = app.YMnimoEditField.Value;
        ymax = app.YMximoEditField.Value;

        % Generamos un vector de 1000 puntos en x en el rango (xmin, xmax)
        x = linspace(xmin, xmax, 1000);
        
        % Convertimos la cadena de la función en una función anónima de MATLAB
        try
            f = str2func(['@(x)', funcionIngresada]);
        catch ME
            app.RazEditField.Value = 'Error en la función ingresada';
            disp(['Error al crear la función anónima: ', ME.message]);
            return;
        end

        % Evaluamos la función en los puntos x
        try
            y = f(x);
        catch ME
            app.RazEditField.Value = 'Error al evaluar la función';
            disp(['Error al evaluar la función: ', ME.message]);
            return;
        end

        % Graficamos la función 
        plot(app.UIAxes, x, y);
        xlabel(app.UIAxes, 'x');
        ylabel(app.UIAxes, 'f(x)');
        title(app.UIAxes, 'x y f(x)');

         % Verificar si xmin y xmax son números válidos y si xmin es menor que xmax
        if isnumeric(xmin) && isnumeric(xmax) && xmin < xmax
            % Asignar el intervalo [xmin, xmax] al eje x
            app.UIAxes.XLim = [xmin, xmax];
            app.UIAxes.YLim = [ymin, ymax];
        elseif isinf(xmax)
            % Si xmax es infinito, asignar solo el límite inferior
            app.UIAxes.XLim = [xmin, Inf];
        else
            % Mostrar un mensaje de error si xmin o xmax no son válidos
            disp('Error: xmin y xmax deben ser números válidos y xmin debe ser menor que xmax');
        end

        % Intentamos encontrar las raíces de la función
        % Para cualquier tipo de función
        try
            
            % Convertimos la función ingresada a una expresión simbólica
            func_sym = str2sym(funcionIngresada);
        
            % Encontramos las raíces de la función en el intervalo [xmin, xmax]
            rootsOfFunction = vpasolve(func_sym == 0, [xmin, xmax]);
        
            % Convertimos las raíces a números reales (dobles)
            rootsOfFunction = double(rootsOfFunction);
        
            % Filtramos las raíces reales dentro del rango especificado
            realRoots = rootsOfFunction(imag(rootsOfFunction) == 0 & rootsOfFunction >= xmin & rootsOfFunction <= xmax);
        
            % Convertimos las raíces reales a una cadena para mostrar en la UI
            if isempty(realRoots)
                app.RazEditField.Value = 'xmin y xmax deben ser números válidos y xmin debe ser menor que xmax';
            else
                app.RazEditField.Value = num2str(realRoots);
            end
        catch ME
            % Si ocurre un error, mostramos un mensaje en la UI y en la consola
            app.RazEditField.Value = 'Error, no se pudo calcular las raíces. El rango ingresado es inválido';
            disp(['Error al calcular las raíces: ', ME.message]);
        end
     
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 640 480];
            app.UIFigure.Name = 'MATLAB App';

            % Create UIAxes
            app.UIAxes = uiaxes(app.UIFigure);
            title(app.UIAxes, 'Title')
            xlabel(app.UIAxes, 'X')
            ylabel(app.UIAxes, 'Y')
            zlabel(app.UIAxes, 'Z')
            app.UIAxes.Tag = 'axesGrafico';
            app.UIAxes.Position = [211 101 390 250];

            % Create IndicacionesLabel
            app.IndicacionesLabel = uilabel(app.UIFigure);
            app.IndicacionesLabel.Tag = 'textoIngreso';
            app.IndicacionesLabel.Position = [11 429 72 22];
            app.IndicacionesLabel.Text = 'Indicaciones';

            % Create GraficarButton
            app.GraficarButton = uibutton(app.UIFigure, 'push');
            app.GraficarButton.ButtonPushedFcn = createCallbackFcn(app, @GraficarButtonPushed, true);
            app.GraficarButton.Tag = 'btnGraficar';
            app.GraficarButton.Position = [481 349 100 22];
            app.GraficarButton.Text = 'Graficar';

            % Create XMximoEditFieldLabel
            app.XMximoEditFieldLabel = uilabel(app.UIFigure);
            app.XMximoEditFieldLabel.HorizontalAlignment = 'right';
            app.XMximoEditFieldLabel.Position = [22 236 58 22];
            app.XMximoEditFieldLabel.Text = 'X Máximo';

            % Create XMximoEditField
            app.XMximoEditField = uieditfield(app.UIFigure, 'numeric');
            app.XMximoEditField.Tag = 'numXmax';
            app.XMximoEditField.Position = [95 236 100 22];

            % Create XMnimoEditFieldLabel
            app.XMnimoEditFieldLabel = uilabel(app.UIFigure);
            app.XMnimoEditFieldLabel.HorizontalAlignment = 'right';
            app.XMnimoEditFieldLabel.Position = [23 276 56 22];
            app.XMnimoEditFieldLabel.Text = 'X Mínimo';

            % Create XMnimoEditField
            app.XMnimoEditField = uieditfield(app.UIFigure, 'numeric');
            app.XMnimoEditField.Tag = 'numXmin';
            app.XMnimoEditField.Position = [94 276 100 22];

            % Create YMximoEditFieldLabel
            app.YMximoEditFieldLabel = uilabel(app.UIFigure);
            app.YMximoEditFieldLabel.HorizontalAlignment = 'right';
            app.YMximoEditFieldLabel.Position = [21 159 58 22];
            app.YMximoEditFieldLabel.Text = 'Y Máximo';

            % Create YMximoEditField
            app.YMximoEditField = uieditfield(app.UIFigure, 'numeric');
            app.YMximoEditField.Tag = 'numYmax';
            app.YMximoEditField.Position = [94 159 100 22];

            % Create YMnimoEditFieldLabel
            app.YMnimoEditFieldLabel = uilabel(app.UIFigure);
            app.YMnimoEditFieldLabel.HorizontalAlignment = 'right';
            app.YMnimoEditFieldLabel.Position = [25 194 55 22];
            app.YMnimoEditFieldLabel.Text = 'Y Mínimo';

            % Create YMnimoEditField
            app.YMnimoEditField = uieditfield(app.UIFigure, 'numeric');
            app.YMnimoEditField.Tag = 'numYmin';
            app.YMnimoEditField.Position = [95 194 100 22];

            % Create RazEditFieldLabel
            app.RazEditFieldLabel = uilabel(app.UIFigure);
            app.RazEditFieldLabel.HorizontalAlignment = 'right';
            app.RazEditFieldLabel.Position = [33 49 30 22];
            app.RazEditFieldLabel.Text = 'Raíz';

            % Create RazEditField
            app.RazEditField = uieditfield(app.UIFigure, 'text');
            app.RazEditField.Tag = 'txtRaices';
            app.RazEditField.Position = [78 28 61 43];

            % Create fxEditFieldLabel
            app.fxEditFieldLabel = uilabel(app.UIFigure);
            app.fxEditFieldLabel.HorizontalAlignment = 'right';
            app.fxEditFieldLabel.Position = [21 329 36 22];
            app.fxEditFieldLabel.Text = 'f(x) = ';

            % Create fxEditField
            app.fxEditField = uieditfield(app.UIFigure, 'text');
            app.fxEditField.Tag = 'txtFuncion';
            app.fxEditField.Position = [72 329 100 22];

            % Create Label
            app.Label = uilabel(app.UIFigure);
            app.Label.Position = [11 411 480 20];
            app.Label.Text = 'Ingresar la función utilizando un * para las multiplicaciones y un . antes del ^ para elevar.';

            % Create Label_2
            app.Label_2 = uilabel(app.UIFigure);
            app.Label_2.Position = [11 389 481 22];
            app.Label_2.Text = 'Los valores de X Mínimo y Y Mínimo deben de ser menores que X Máximo y Y Máximo.';

            % Create GraficadoradeFuncionesLabel
            app.GraficadoradeFuncionesLabel = uilabel(app.UIFigure);
            app.GraficadoradeFuncionesLabel.Position = [231 449 143 22];
            app.GraficadoradeFuncionesLabel.Text = 'Graficadora de Funciones';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = GraficadoraMetodos_exported

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end